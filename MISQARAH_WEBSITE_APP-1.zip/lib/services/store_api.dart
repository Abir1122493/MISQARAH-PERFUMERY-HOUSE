import 'dart:convert';
import 'package:http/http.dart' as http;

/// Connect this app to your own secure backend.
/// NEVER put WooCommerce Consumer Secret in the mobile app.
class StoreApi {
  static const String baseUrl = String.fromEnvironment(
    'STORE_API_URL',
    defaultValue: 'https://YOUR-SECURE-BACKEND.example.com',
  );

  static Future<List<dynamic>> fetchProducts() async {
    final response = await http.get(Uri.parse('$baseUrl/products'));
    if (response.statusCode != 200) {
      throw Exception('Could not load products (${response.statusCode})');
    }
    return jsonDecode(response.body) as List<dynamic>;
  }
}
