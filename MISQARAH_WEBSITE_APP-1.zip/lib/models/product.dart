class Product {
  final String name;
  final String category;
  final String price;
  final String note;

  const Product({
    required this.name,
    required this.category,
    required this.price,
    required this.note,
  });
}
