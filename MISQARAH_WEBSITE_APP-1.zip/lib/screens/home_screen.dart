import 'package:flutter/material.dart';
import '../models/product.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _selectedIndex = 0;
  final List<Product> _products = const [
    Product(name: 'Oud Collection', category: 'ARABIAN OUD', price: 'Explore', note: 'Rich • Woody • Elegant'),
    Product(name: 'Signature Musk', category: 'PREMIUM ATTAR', price: 'Explore', note: 'Soft • Smooth • Long-lasting'),
    Product(name: 'Floral Essence', category: 'WOMEN', price: 'Explore', note: 'Fresh • Floral • Graceful'),
    Product(name: 'Classic Pour Homme', category: 'MEN', price: 'Explore', note: 'Bold • Refined • Timeless'),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Column(
          children: [
            Text('MISQARAH', style: TextStyle(letterSpacing: 3, fontWeight: FontWeight.w800, fontSize: 19)),
            Text('PERFUMERY HOUSE', style: TextStyle(letterSpacing: 2.2, fontSize: 9)),
          ],
        ),
        actions: [
          IconButton(onPressed: () => _message('Search will be connected to the store.'), icon: const Icon(Icons.search)),
          IconButton(onPressed: () => _message('Your shopping bag is ready for WooCommerce integration.'), icon: const Icon(Icons.shopping_bag_outlined)),
        ],
      ),
      body: IndexedStack(
        index: _selectedIndex,
        children: [
          _homeContent(),
          _simplePage('CATEGORIES', 'Explore perfumes, attars and fragrance collections.'),
          _simplePage('MY ORDERS', 'Sign in to view your order history and delivery updates.'),
          _simplePage('MY ACCOUNT', 'Customer login and profile will connect to your store.'),
        ],
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _selectedIndex,
        onDestinationSelected: (value) => setState(() => _selectedIndex = value),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.grid_view_outlined), label: 'Categories'),
          NavigationDestination(icon: Icon(Icons.receipt_long_outlined), label: 'Orders'),
          NavigationDestination(icon: Icon(Icons.person_outline), label: 'Account'),
        ],
      ),
    );
  }

  Widget _homeContent() {
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 18, 16, 28),
      children: [
        Container(
          padding: const EdgeInsets.all(22),
          decoration: BoxDecoration(
            color: const Color(0xFF171717),
            borderRadius: BorderRadius.circular(18),
            gradient: const LinearGradient(
              colors: [Color(0xFF101010), Color(0xFF383027)],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
          ),
          child: const Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('THE ART OF', style: TextStyle(color: Color(0xFFD8B36B), letterSpacing: 3, fontSize: 11)),
              SizedBox(height: 5),
              Text('Fragrance', style: TextStyle(color: Colors.white, fontSize: 34, fontWeight: FontWeight.w300)),
              SizedBox(height: 8),
              Text('Discover a scent that speaks for you.', style: TextStyle(color: Colors.white70, fontSize: 13)),
              SizedBox(height: 18),
              Text('DISCOVER COLLECTION  →', style: TextStyle(color: Color(0xFFE0BD78), letterSpacing: 1.4, fontSize: 10, fontWeight: FontWeight.bold)),
            ],
          ),
        ),
        const SizedBox(height: 26),
        const _SectionTitle(title: 'SHOP BY CATEGORY', subtitle: 'Find your signature scent'),
        const SizedBox(height: 12),
        Wrap(
          spacing: 9,
          runSpacing: 9,
          children: ['MEN', 'WOMEN', 'ATTAR', 'ARABIAN', 'UNISEX'].map((e) => Chip(
            label: Text(e, style: const TextStyle(fontSize: 11, letterSpacing: 1)),
            backgroundColor: Colors.white,
            side: const BorderSide(color: Color(0xFFE7DDCC)),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
          )).toList(),
        ),
        const SizedBox(height: 25),
        const _SectionTitle(title: 'FEATURED COLLECTIONS', subtitle: 'Curated for every moment'),
        const SizedBox(height: 12),
        GridView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          itemCount: _products.length,
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2, crossAxisSpacing: 12, mainAxisSpacing: 12, childAspectRatio: .88,
          ),
          itemBuilder: (context, index) {
            final p = _products[index];
            return Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: const Color(0xFFECE5D9)),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Expanded(
                    child: Container(
                      width: double.infinity,
                      decoration: BoxDecoration(
                        color: const Color(0xFFF2EEE7),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: const Icon(Icons.spa_outlined, size: 48, color: Color(0xFFB38A43)),
                    ),
                  ),
                  const SizedBox(height: 10),
                  Text(p.category, style: const TextStyle(color: Color(0xFFB38A43), fontSize: 9, letterSpacing: 1.2, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 4),
                  Text(p.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w700)),
                  const SizedBox(height: 3),
                  Text(p.note, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.black54, fontSize: 10)),
                ],
              ),
            );
          },
        ),
        const SizedBox(height: 20),
        const Center(child: Text('MISQARAH PERFUMERY HOUSE', style: TextStyle(letterSpacing: 1.8, fontSize: 10, color: Colors.black54))),
      ],
    );
  }

  Widget _simplePage(String title, String description) => Center(
    child: Padding(
      padding: const EdgeInsets.all(28),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        const Icon(Icons.spa_outlined, size: 42, color: Color(0xFFC69A45)),
        const SizedBox(height: 14),
        Text(title, style: const TextStyle(fontWeight: FontWeight.bold, letterSpacing: 2)),
        const SizedBox(height: 8),
        Text(description, textAlign: TextAlign.center, style: const TextStyle(color: Colors.black54)),
      ]),
    ),
  );

  void _message(String message) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
  }
}

class _SectionTitle extends StatelessWidget {
  final String title;
  final String subtitle;
  const _SectionTitle({required this.title, required this.subtitle});

  @override
  Widget build(BuildContext context) => Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Text(title, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w800, letterSpacing: 1.4)),
      const SizedBox(height: 4),
      Text(subtitle, style: const TextStyle(fontSize: 11, color: Colors.black54)),
    ],
  );
}
