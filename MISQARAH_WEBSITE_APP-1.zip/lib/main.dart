import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const MisqarahWebsiteApp());
}

class MisqarahWebsiteApp extends StatefulWidget {
  const MisqarahWebsiteApp({super.key});

  @override
  State<MisqarahWebsiteApp> createState() => _MisqarahWebsiteAppState();
}

class _MisqarahWebsiteAppState extends State<MisqarahWebsiteApp> {
  late final WebViewController _controller;
  bool _loading = true;
  bool _failed = false;

  @override
  void initState() {
    super.initState();
    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setNavigationDelegate(NavigationDelegate(
        onPageStarted: (_) => setState(() { _loading = true; _failed = false; }),
        onPageFinished: (_) => setState(() => _loading = false),
        onWebResourceError: (error) {
          if (error.isForMainFrame == true) {
            setState(() { _loading = false; _failed = true; });
          }
        },
      ))
      ..loadRequest(Uri.parse('https://misqarahperfumeryhouse.com'));
  }

  Future<bool> _back() async {
    if (await _controller.canGoBack()) {
      await _controller.goBack();
      return false;
    }
    return true;
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'MISQARAH PERFUMERY HOUSE',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFFC69A45))),
      home: WillPopScope(
        onWillPop: _back,
        child: Scaffold(
          appBar: AppBar(
            title: const Text('MISQARAH PERFUMERY HOUSE'),
            actions: [
              IconButton(
                tooltip: 'Reload website',
                icon: const Icon(Icons.refresh),
                onPressed: () => _controller.reload(),
              ),
            ],
          ),
          body: Stack(
            children: [
              WebViewWidget(controller: _controller),
              if (_loading) const LinearProgressIndicator(),
              if (_failed)
                Center(
                  child: Padding(
                    padding: const EdgeInsets.all(24),
                    child: Column(mainAxisSize: MainAxisSize.min, children: [
                      const Icon(Icons.wifi_off, size: 48),
                      const SizedBox(height: 12),
                      const Text('Website load হচ্ছে না। Internet connection চেক করে আবার চেষ্টা করুন।',
                          textAlign: TextAlign.center),
                      const SizedBox(height: 12),
                      ElevatedButton(
                        onPressed: () => _controller.reload(),
                        child: const Text('Retry'),
                      ),
                    ]),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}
