MISQARAH Website Android App
===========================
Website URL: https://misqarahperfumeryhouse.com

Build steps:
1) Extract this ZIP to app_src.
2) Run: flutter create --platforms=android --project-name=misqarah_perfumery_house .
3) Run: flutter pub get
4) Run: flutter build apk --release

GitHub Actions can do these steps automatically.
