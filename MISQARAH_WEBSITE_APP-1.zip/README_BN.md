# MISQARAH PERFUMERY HOUSE — Flutter App Starter

এটি Android ও iOS-এর জন্য Flutter অ্যাপের প্রাথমিক সোর্স প্রজেক্ট।

## এখন কী আছে
- MISQARAH PERFUMERY HOUSE ব্র্যান্ডিং
- Black / Gold / Ivory ডিজাইন
- Home, Categories, Orders ও Account ট্যাব
- Featured collection-এর ডেমো কার্ড
- Secure backend API সংযোগের placeholder

## গুরুত্বপূর্ণ সীমাবদ্ধতা
এই প্রজেক্টটি এখনো WooCommerce-এর সঙ্গে live connected নয়। Products, stock, price, login, cart, checkout, order tracking, payment gateway এবং push notification চালু করতে secure backend ও WooCommerce integration সম্পন্ন করতে হবে। এই ZIP নিজে থেকে APK/IPA নয়।

## নিরাপত্তা
WooCommerce Consumer Key/Secret কখনো Flutter app-এর মধ্যে রাখবেন না। এগুলো secure server/backend-এ রাখতে হবে। কোনো password বা secret chat-এ পাঠাবেন না।

## চালানোর জন্য
1. Flutter SDK ও Android Studio ইনস্টল করুন।
2. এই ফোল্ডারে terminal খুলুন।
3. `flutter pub get`
4. `flutter run`

iOS build করতে macOS ও Xcode প্রয়োজন।

## পরবর্তী কাজ
- আপনার WooCommerce store-এর জন্য secure backend endpoint তৈরি
- API credentials server environment-এ সংরক্ষণ
- Real products/categories/images ও search সংযুক্ত
- Cart, checkout, customer authentication ও order history
- Payment gateway এবং push notifications
- আপনার দেওয়া আসল logo ও product photos assets হিসেবে যুক্ত
- Android/iOS release build ও store publishing
