import 'package:flutter/material.dart';
import 'screens/home_screen.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const MisqarahApp());
}

class MisqarahApp extends StatelessWidget {
  const MisqarahApp({super.key});

  @override
  Widget build(BuildContext context) {
    const gold = Color(0xFFC69A45);
    return MaterialApp(
      title: 'MISQARAH PERFUMERY HOUSE',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        scaffoldBackgroundColor: const Color(0xFFFAF8F4),
        colorScheme: ColorScheme.fromSeed(
          seedColor: gold,
          brightness: Brightness.light,
          surface: const Color(0xFFFAF8F4),
        ),
        appBarTheme: const AppBarTheme(
          backgroundColor: Color(0xFF111111),
          foregroundColor: Colors.white,
          centerTitle: true,
        ),
        fontFamily: 'Roboto',
      ),
      home: const HomeScreen(),
    );
  }
}
